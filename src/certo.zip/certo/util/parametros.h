#ifndef PARAMETROS
#define PARAMETROS

void getParametros(int argc,char *argv[],char **pGeo,char **pQry,char **localEntrada,char **localSaida,char **estabComercial,char **pessoas,int *modoInterativo);

#endif