#ifndef FIGURAS
#define FIGURAS

#include "circulo.h"
#include "retangulo.h"
#include "texto.h"
#include "hidrante.h"
#include "semaforo.h"
#include "radio.h"
#include "quadra.h"

#include "muro.h"
#include "predio.h"

#include "pessoa.h"
#include "morador.h"
#include "tipoEstabelecimento.h"
#include "estabelecimento.h"

#endif
